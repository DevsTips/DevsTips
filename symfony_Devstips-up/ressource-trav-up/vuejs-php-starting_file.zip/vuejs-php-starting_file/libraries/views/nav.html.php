<nav>
  <div>
    <a href="">
      <img id="logo" src="./assets/img/logo.jpg" alt="logo" />
    </a>
  </div>
  <ul>
    <li>
      <a href="">
        <i class="fas fa-sign-in-alt"></i>
      </a>
    </li>
  </ul>
</nav>