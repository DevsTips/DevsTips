<?php

// call template
require_once 'libraries/utils.php';
render('lobby');

?>